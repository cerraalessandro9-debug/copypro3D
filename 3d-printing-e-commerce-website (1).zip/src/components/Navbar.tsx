"use client";

import Link from "next/link";
import { useState } from "react";
import { useCart } from "@/lib/cart";
import { ShoppingCart, Menu, X, Mail, Phone, MapPin } from "lucide-react";

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { itemCount } = useCart();

  return (
    <nav className="fixed top-0 w-full z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 via-orange-500 to-cyan-400 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                <span className="text-white font-bold text-xs">C3D</span>
              </div>
              <span className="font-bold text-xl tracking-tight text-white bg-clip-text text-transparent bg-gradient-to-r from-cyan-300 via-orange-400 to-cyan-300">
                CopyPro3D.it
              </span>
            </Link>
          </div>

          <div className="hidden md:flex items-center gap-8 text-sm font-medium">
            <Link href="/" className="text-white/90 hover:text-cyan-400 transition-colors">Home</Link>
            <Link href="/prodotti" className="text-white/90 hover:text-cyan-400 transition-colors">Prodotti</Link>
            <Link href="/contatti" className="text-white/90 hover:text-cyan-400 transition-colors">Contatti</Link>
            <a href="https://wa.me/393714227933" className="text-white/90 hover:text-cyan-400 transition-colors flex items-center gap-1">
              <Phone size={16} /> WhatsApp
            </a>
          </div>

          <div className="flex items-center gap-4">
            <Link href="/carrello" className="relative group">
              <ShoppingCart size={20} className="text-white/90 group-hover:text-cyan-400 transition-colors" />
              {itemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-orange-500 text-[10px] font-bold px-1.5 py-0.5 rounded-full animate-bounce">
                  {itemCount}
                </span>
              )}
            </Link>
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden text-white/90"
              aria-label="Open menu"
            >
              <Menu size={24} />
            </button>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-black/90 backdrop-blur-md border-b border-white/10">
          <div className="max-w-7xl mx-auto px-4 py-6 space-y-4">
            <Link href="/" onClick={() => setMobileMenuOpen(false)} className="block text-white/90 hover:text-cyan-400 py-2 transition-colors">Home</Link>
            <Link href="/prodotti" onClick={() => setMobileMenuOpen(false)} className="block text-white/90 hover:text-cyan-400 py-2 transition-colors">Prodotti</Link>
            <Link href="/contatti" onClick={() => setMobileMenuOpen(false)} className="block text-white/90 hover:text-cyan-400 py-2 transition-colors">Contatti</Link>
            <a href="https://wa.me/393714227933" onClick={() => setMobileMenuOpen(false)} className="block text-white/90 hover:text-cyan-400 py-2 transition-colors flex items-center gap-2">
              <Phone size={16} /> WhatsApp: +39 371 422 7933
            </a>
            <a href="mailto:cerraalessandro9@gmail.com" onClick={() => setMobileMenuOpen(false)} className="block text-white/90 hover:text-cyan-400 py-2 transition-colors flex items-center gap-2">
              <Mail size={16} /> cerraalessandro9@gmail.com
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}

export function ContactBar() {
  return (
    <div className="bg-gradient-to-r from-cyan-900/90 via-black/90 to-cyan-900/90 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-center gap-6 py-3 text-xs sm:text-sm md:justify-between md:text-base">
          <div className="flex items-center gap-2 text-white/90">
            <Mail size={14} className="text-cyan-400" />
            <a href="mailto:cerraalessandro9@gmail.com" className="hover:text-cyan-400 transition-colors">
              cerraalessandro9@gmail.com
            </a>
          </div>
          <div className="flex items-center gap-2 text-white/90">
            <Phone size={14} className="text-cyan-400" />
            <a href="tel:+393714227933" className="hover:text-cyan-400 transition-colors">
              +39 371 422 7933
            </a>
          </div>
          <div className="flex items-center gap-2 text-white/90">
            <MapPin size={14} className="text-cyan-400" />
            <span>Via Giacomo Matteotti 105, 42046 Reggiolo (RE)</span>
          </div>
        </div>
      </div>
    </div>
  );
}
