"use client";

import Link from "next/link";
import { useCart } from "@/lib/cart";
import { Plus, Upload } from "lucide-react";

interface ProductCardProps {
  product: {
    id: number;
    name: string;
    slug: string;
    description: string;
    shortDescription?: string;
    price: number;
    category: string;
    imageUrl: string;
    customizable: boolean;
    stock: number;
    featured: boolean;
    color?: string;
  };
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  const isCustomizable = product.customizable;

  return (
    <article className="group relative bg-white/5 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-sm hover:border-cyan-400/50 transition-all duration-300">
      {/* 3D Tilt Container */}
      <div className="relative h-64 overflow-hidden">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
        
        {product.stock === 0 && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="px-4 py-1 bg-red-500 text-white text-xs font-bold rounded uppercase tracking-wider">
              Esaurito
            </span>
          </div>
        )}

        {product.featured && (
          <div className="absolute top-4 left-4 bg-cyan-500 text-black text-xs font-bold px-2 py-1 rounded uppercase tracking-wider animate-pulse">
            In Evidenza
          </div>
        )}

        {isCustomizable && (
          <div className="absolute top-4 right-4 bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded uppercase tracking-wider">
            Personalizzabile
          </div>
        )}
      </div>

      <div className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <p className="text-xs text-cyan-400 uppercase tracking-wider font-semibold mb-1">
              {product.category}
            </p>
            <Link href={`/prodotto/${product.slug}`} className="block text-white font-semibold text-lg mb-2 group-hover:text-cyan-400 transition-colors">
              {product.name}
            </Link>
            <p className="text-white/60 text-sm line-clamp-2 mb-3">
              {product.shortDescription || product.description}
            </p>
          </div>
          <span className="text-cyan-400 font-bold text-xl">
            €{product.price.toFixed(2)}
          </span>
        </div>

        <div className="flex gap-2">
          {isCustomizable ? (
            <Link
              href={`/prodotto/${product.slug}?custom=true`}
              className="flex-1 bg-cyan-500 hover:bg-cyan-400 text-white text-xs font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2 group-hover:scale-[1.02]"
            >
              <Upload size={14} className="text-orange-400" />
              Personalizza
            </Link>
          ) : (
            <>
              <button
                onClick={() => {
                  addItem({
                    productId: product.id,
                    name: product.name,
                    price: Number(product.price),
                    imageUrl: product.imageUrl,
                  });
                }}
                disabled={product.stock === 0}
                className="flex-1 bg-gradient-to-r from-cyan-500 via-cyan-600 to-orange-500 hover:from-cyan-400 hover:via-cyan-500 hover:to-orange-400 text-white text-xs font-bold py-3 px-4 rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed group-hover:scale-[1.02] flex items-center justify-center gap-2"
              >
                <Plus size={14} />
                Aggiungi
              </button>
            </>
          )}
        </div>
      </div>
    </article>
  );
}
