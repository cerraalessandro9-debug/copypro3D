export function Footer() {
  return (
    <footer className="bg-black border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 via-orange-500 to-cyan-400 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                <span className="text-white font-bold text-xs">C3D</span>
              </div>
              <span className="font-bold text-xl tracking-tight text-white bg-clip-text text-transparent bg-gradient-to-r from-cyan-300 via-orange-400 to-cyan-300">
                CopyPro3D.it
              </span>
            </div>
            <p className="text-white/60 text-sm leading-relaxed">
              Stampa 3D professionale FDM con filamenti PLA. Prodotti personalizzabili tramite file STL.
            </p>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Prodotti</h3>
            <ul className="space-y-2 text-white/60 text-sm">
              <li><a href="/prodotti?category=gadgets" className="hover:text-cyan-400 transition-colors">Gadget Tech</a></li>
              <li><a href="/prodotti?category=home" className="hover:text-cyan-400 transition-colors">Casa e Arredo</a></li>
              <li><a href="/prodotti?category=toys" className="hover:text-cyan-400 transition-colors">Giocattoli e Modellismo</a></li>
              <li><a href="/prodotti?category=custom" className="hover:text-cyan-400 transition-colori">Personalizzati</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Informazioni</h3>
            <ul className="space-y-2 text-white/60 text-sm">
              <li><a href="/contatti" className="hover:text-cyan-400 transition-colors">Contatti</a></li>
              <li><a href="#" className="hover:text-cyan-400 transition-colors">Spedizioni</a></li>
              <li><a href="#" className="hover:text-cyan-400 transition-colors">Resi e Rimborso</a></li>
              <li><a href="#" className="hover:text-cyan-400 transition-colors">Privacy Policy</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Contatti</h3>
            <ul className="space-y-2 text-white/60 text-sm">
              <li className="flex items-center gap-2">
                <span className="text-cyan-400">✉</span>
                <a href="mailto:cerraalessandro9@gmail.com" className="hover:text-cyan-400 transition-colors">cerraalessandro9@gmail.com</a>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-cyan-400">📱</span>
                <a href="tel:+393714227933" className="hover:text-cyan-400 transition-colors">+39 371 422 7933</a>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-cyan-400">📍</span>
                <span>Via Giacomo Matteotti 105<br className="hidden md:block" />42046 Reggiolo (RE)</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8">
          <p className="text-white/40 text-xs text-center">
            CopyPro3D.it - Stampa 3D Professionale. P.IVA: IT00000000000
          </p>
        </div>
      </div>
    </footer>
  );
}
