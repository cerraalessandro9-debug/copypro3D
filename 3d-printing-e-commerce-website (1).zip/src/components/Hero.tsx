export function Hero() {
  return (
    <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden bg-black">
      {/* Background 3D gradient orbs */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-cyan-500/20 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-orange-500/20 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: "2s" }}></div>
        <div className="absolute top-[20%] right-[20%] w-[40%] h-[40%] bg-cyan-500/10 rounded-full blur-[100px]" style={{ animationDelay: "4s" }}></div>
      </div>

      {/* Logo / Brand */}
      <div className="text-center px-4 sm:px-6 lg:px-8">
        <div className="inline-block relative">
          <div className="absolute -inset-1 bg-gradient-to-r from-cyan-400 via-orange-500 to-cyan-400 rounded-full blur opacity-25 animate-[spin_4s_linear_infinite]"></div>
          <div className="relative w-32 h-32 mx-auto mb-8 rounded-full border-2 border-white/20 bg-white/5 backdrop-blur-md flex items-center justify-center overflow-hidden relative">
            <span className="text-6xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-orange-400 drop-shadow-[0_0_20px_rgba(6,182,212,0.6)]">
              C3D
            </span>
          </div>
        </div>

        <h1 className="text-[clamp(2.5rem,8vw,5rem)] font-black tracking-tighter text-white mb-6 drop-shadow-[0_4px_6px_rgba(0,0,0,0.3)]">
          CopyPro3D.it
        </h1>
        <p className="text-[clamp(1rem,3vw,1.25rem)] text-white/70 mb-8 max-w-2xl mx-auto leading-relaxed">
          Stampa 3D Professionale FDM con filamenti PLA.<br />
          Prodotti personalizzabili tramite file STL. Realizziamo le tue idee in tre dimensioni.
        </p>

        <div className="flex flex-wrap justify-center gap-4 sm:gap-6">
          <a
            href="/prodotti"
            className="group relative px-8 py-4 bg-gradient-to-r from-cyan-500 via-orange-500 to-cyan-500 text-white font-bold rounded-xl overflow-hidden shadow-[0_0_30px_rgba(6,182,212,0.4)] transition-all hover:shadow-[0_0_50px_rgba(6,182,212,0.6)] hover:-translate-y-1"
          >
            <span className="relative z-10">Scopri i Prodotti</span>
            <div className="absolute inset-0 bg-white/20 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></div>
          </a>
          <a
            href="https://wa.me/393714227933"
            className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl border border-white/20 transition-all hover:-translate-y-1"
          >
            Contattaci su WhatsApp
          </a>
        </div>
      </div>

      {/* Decorative 3D elements */}
      <div className="absolute top-1/4 left-10 w-20 h-1 border-t border-cyan-500/30" />
      <div className="absolute top-1/4 right-10 w-20 h-1 border-t border-orange-500/30" />
      <div className="absolute bottom-1/4 left-1/4 w-1 h-20 border-l border-cyan-500/30" />
      <div className="absolute bottom-1/4 right-1/4 w-1 h-20 border-l border-orange-500/30" />
    </section>
  );
}
