import { NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq, and, ilike, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const featured = searchParams.get("featured");
    const search = searchParams.get("search");
    const customizable = searchParams.get("customizable");

    const conditions: any[] = [];

    if (category) {
      conditions.push(eq(products.category, category));
    }

    if (featured === "true") {
      conditions.push(eq(products.featured, true));
    }

    if (customizable === "true") {
      conditions.push(eq(products.customizable, true));
    }

    if (search) {
      conditions.push(ilike(products.name, `%${search}%`));
    }

    let allProducts;
    if (conditions.length > 0) {
      allProducts = await db.select().from(products).where(and(...conditions));
    } else {
      allProducts = await db.select().from(products);
    }

    return NextResponse.json({ products: allProducts });
  } catch (error) {
    console.error("Error fetching products:", error);
    return NextResponse.json(
      { error: "Failed to fetch products" },
      { status: 500 }
    );
  }
}
