import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, products } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

interface OrderItemInput {
  productId: number;
  quantity: number;
  customStlFileUrl?: string | null;
  customNotes?: string | null;
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      customerName,
      customerEmail,
      customerPhone,
      customerAddress,
      customerCity,
      customerCap,
      customerProvince,
      items,
      notes,
    } = body;

    if (!customerName || !customerEmail || !items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Generate order number
    const orderNumber = "CP3D-" + Date.now().toString().slice(-6);

    // Calculate total and verify stock
    let total = 0;
    const orderItemsData: OrderItemInput[] = [];

    for (const item of items) {
      const productResult = await db.select().from(products).where(eq(products.id, item.productId)).limit(1);
      if (!productResult[0]) {
        return NextResponse.json({ error: `Product ${item.productId} not found` }, { status: 400 });
      }
      const p = productResult[0];
      const stock = p.stock ?? 0;
      if (stock < item.quantity) {
        return NextResponse.json({ error: `Insufficient stock for ${p.name}` }, { status: 400 });
      }
      const itemTotal = Number(p.price) * item.quantity;
      total += itemTotal;
      orderItemsData.push({
        productId: p.id,
        quantity: item.quantity,
        customStlFileUrl: item.customStlFileUrl ?? null,
        customNotes: item.customNotes ?? null,
      });
    }

    // Create order and items in a transaction
    const result = await db.transaction(async (tx) => {
      const [newOrder] = await tx.insert(orders).values({
        orderNumber,
        customerName,
        customerEmail,
        customerPhone,
        customerAddress,
        customerCity,
        customerCap,
        customerProvince,
        total: total.toString(),
        notes: notes ?? null,
      }).returning();

      for (const item of orderItemsData) {
        const productResult = await tx.select().from(products).where(eq(products.id, item.productId)).limit(1);
        const price = productResult[0].price;
        await tx.insert(orderItems).values({
          orderId: newOrder.id,
          productId: item.productId,
          quantity: item.quantity,
          priceAtPurchase: price,
          customStlFileUrl: item.customStlFileUrl,
          customNotes: item.customNotes,
        });
      }

      // Update stock
      for (const item of items) {
        await tx.update(products)
          .set({ stock: sql`${products.stock} - ${item.quantity}` })
          .where(eq(products.id, item.productId));
      }

      return newOrder;
    });

    return NextResponse.json({
      success: true,
      order: result,
      orderNumber,
      total,
    });
  } catch (error) {
    console.error("Error creating order:", error);
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 });
  }
}
