"use client";

import { useCart } from "@/lib/cart";
import Link from "next/link";
import { Trash2, ChevronLeft, Mail, Phone } from "lucide-react";
import { ContactBar } from "@/components/Navbar";

export default function CartPage() {
  const { items, total, itemCount, removeItem, updateQuantity, clearCart } = useCart();

  return (
    <main className="bg-black text-white min-h-screen">
      <ContactBar />

      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <Link href="/prodotti" className="flex items-center gap-2 text-cyan-400 hover:text-white transition-colors">
              <ChevronLeft size={18} /> Continua gli acquisti
            </Link>
            <h1 className="text-3xl font-black tracking-tight text-white">
              Carrello ({itemCount})
            </h1>
          </div>

          {items.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6 text-white/50">
                <Trash2 size={32} />
              </div>
              <h2 className="text-2xl font-bold text-white mb-4">Il tuo carrello è vuoto</h2>
              <p className="text-white/60 mb-8">Non hai ancora aggiunto prodotti al carrello.</p>
              <Link href="/prodotti" className="bg-gradient-to-r from-cyan-500 via-orange-500 to-cyan-500 text-white font-bold px-8 py-3 rounded-xl hover:shadow-[0_0_30px_rgba(6,182,212,0.4)] transition-all">
                Vai ai Prodotti
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="space-y-4">
                  {items.map((item) => (
                    <div key={item.productId} className="bg-white/5 border border-white/10 rounded-2xl p-4 flex gap-4">
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-20 h-20 object-cover rounded-xl bg-white/10"
                      />
                      <div className="flex-1">
                        <h3 className="text-white font-semibold">{item.name}</h3>
                        {item.customNotes && (
                          <p className="text-xs text-cyan-400/80 mt-1">Personalizzato</p>
                        )}
                        <p className="text-cyan-400 font-bold mt-1">
                          €{item.price.toFixed(2)}
                        </p>
                        <div className="flex items-center gap-3 mt-3">
                          <button
                            onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                            className="w-8 h-8 bg-white/5 hover:bg-white/10 rounded-full flex items-center justify-center text-white/50 hover:text-white transition-colors"
                          >
                            −
                          </button>
                          <span className="text-white font-mono">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                            className="w-8 h-8 bg-white/5 hover:bg-white/10 rounded-full flex items-center justify-center text-white/50 hover:text-white transition-colors"
                          >
                            +
                          </button>
                          <button
                            onClick={() => removeItem(item.productId)}
                            className="text-white/50 hover:text-red-400 transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {items.length > 0 && (
                  <button
                    onClick={clearCart}
                    className="mt-6 w-full py-3 bg-red-500/20 border border-red-500/50 text-red-400 rounded-xl hover:bg-red-500/30 transition-colors text-sm font-medium"
                  >
                    Svuota Carrello
                  </button>
                )}
              </div>

              <div className="lg:col-span-1">
                <div className="bg-white/5 border border-white/10 rounded-2xl p-6 sticky top-24">
                  <h3 className="text-white font-bold mb-6">Riepilogo Ordine</h3>
                  <div className="space-y-4 mb-6">
                    <div className="flex justify-between text-sm">
                      <span className="text-white/60">Subtotale</span>
                      <span className="text-white">€{total.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-white/60">Spedizione</span>
                      <span className="text-white">Calcolata al checkout</span>
                    </div>
                    <div className="flex justify-between text-sm border-t border-white/10 pt-3">
                      <span className="text-white font-bold">Totale</span>
                      <span className="text-cyan-400 font-bold">€{total.toFixed(2)}</span>
                    </div>
                  </div>

                  <a href="/checkout" className="w-full bg-gradient-to-r from-cyan-500 via-orange-500 to-cyan-500 text-white font-bold py-4 rounded-xl shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:shadow-[0_0_50px_rgba(6,182,212,0.6)] hover:-translate-y-1 transition-all text-center">
                    Procedi al Checkout
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
