import { products } from "@/db/schema";
import { db } from "@/db";
import { ProductCard } from "@/components/ProductCard";
import { ContactBar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useCart } from "@/lib/cart";
import { Upload, Mail, Phone, MapPin, ShoppingCart } from "lucide-react";
import Link from "next/link";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function ProductDetailPage({
  params,
}: {
  params: { slug: string };
}) {
  const productResult = await db
    .select()
    .from(products)
    .where(eq(products.slug, params.slug))
    .limit(1);

  if (!productResult[0]) {
    return (
      <main className="bg-black text-white min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-black mb-4">Prodotto non trovato</h1>
          <Link href="/prodotti" className="text-cyan-400 hover:text-white">
            Torna ai prodotti →
          </Link>
        </div>
      </main>
    );
  }

  const product = productResult[0];

  return (
    <main className="bg-black text-white min-h-screen">
      <ContactBar />

      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <nav className="flex gap-2 text-xs text-white/50 mb-6">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <Link href="/prodotti" className="hover:text-white transition-colors">Prodotti</Link>
            <span>/</span>
            <span className="text-white">{product.name}</span>
          </nav>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Product Image Gallery */}
            <div className="space-y-4">
              <div className="aspect-square bg-white/5 border border-white/10 rounded-2xl overflow-hidden relative group">
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                {product.customizable && (
                  <div className="absolute top-4 right-4 bg-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                    Personalizzabile con STL
                  </div>
                )}
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="aspect-square bg-white/5 border border-white/10 rounded-xl overflow-hidden opacity-50 hover:opacity-100 transition-opacity"
                  />
                ))}
              </div>
            </div>

            {/* Product Details */}
            <div className="space-y-6">
              <div>
                <span className="text-xs text-cyan-400 uppercase tracking-wider font-semibold">
                  {product.category}
                </span>
                <h1 className="text-4xl font-black tracking-tight mb-2 text-white">
                  {product.name}
                </h1>
                <span className="text-cyan-400 text-2xl font-bold">
                  €{Number(product.price ?? 0).toFixed(2)}
                </span>
              </div>

              <div className="border-t border-white/10 pt-6">
                <h3 className="text-white font-bold mb-3">Descrizione</h3>
                <p className="text-white/70 text-sm leading-relaxed">
                  {product.description}
                </p>
              </div>

              <div className="border-t border-white/10 pt-6">
                <h3 className="text-white font-bold mb-3">Specifiche</h3>
                <div className="grid grid-cols-2 gap-4 text-sm text-white/70">
                  <div className="flex flex-col gap-1">
                    <span className="text-cyan-400 font-semibold">Materiale:</span>
                    <span>PLA (filamento)</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-cyan-400 font-semibold">Tecnologia:</span>
                    <span>FDM (Fused Deposition Modeling)</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-cyan-400 font-semibold">Formato file:</span>
                    <span>STL</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-cyan-400 font-semibold">Colore:</span>
                    <span>{product.color ?? "Diversi colori disponibili"}</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-cyan-400 font-semibold">Disponibilità:</span>
                    <span>
                      {(product.stock ?? 0) > 0 ? "Disponibile" : "Esaurito"}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-cyan-400 font-semibold">Personalizzabile:</span>
                    <span>
                      {product.customizable ? "Sì, carica il tuo STL" : "No"}
                    </span>
                  </div>
                </div>
              </div>

              {product.customizable ? (
                <div className="border border-white/10 rounded-2xl p-6 bg-white/5">
                  <h3 className="text-white font-bold mb-4">Personalizza questo prodotto</h3>
                  <p className="text-white/60 text-sm mb-4">
                    Carica il tuo file STL per richiedere una versione personalizzata di questo oggetto.
                  </p>
                  <div className="border-2 border-dashed border-cyan-400/50 rounded-xl p-6 text-center text-cyan-400/80 hover:text-cyan-400 transition-colors cursor-pointer">
                    <Upload size={24} className="mx-auto mb-3" />
                    <p className="font-semibold">Carica file STL</p>
                    <p className="text-xs mt-1">Max 50 MB • STL, OBJ</p>
                  </div>
                  <textarea
                    className="mt-4 w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                    rows={3}
                    placeholder="Note sulla personalizzazione (dimensioni, colore, modifiche...)"
                  ></textarea>
                </div>
              ) : null}

              <div>
                <button className="w-full bg-gradient-to-r from-cyan-500 via-orange-500 to-cyan-500 text-white font-bold py-5 rounded-xl shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:shadow-[0_0_50px_rgba(6,182,212,0.6)] hover:-translate-y-1 transition-all disabled:opacity-50 disabled:cursor-not-allowed">
                  {(product.stock ?? 0) > 0 ? "Aggiungi al Carrello" : "Esaurito"}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <a
                  href="https://wa.me/393714227933?text=Ciao Alessandro, sono interessato al prodotto: ${product.name}"
                  className="flex items-center justify-center gap-2 px-4 py-3 bg-white/10 border border-white/10 text-white rounded-xl hover:bg-white/20 transition-colors text-sm font-medium"
                >
                  <Phone size={18} className="text-cyan-400" />
                  WhatsApp
                </a>
                <a
                  href="mailto:cerraalessandro9@gmail.com?subject=Richiesta prodotto: ${product.name}"
                  className="flex items-center justify-center gap-2 px-4 py-3 bg-white/10 border border-white/10 text-white rounded-xl hover:bg-white/20 transition-colors text-sm font-medium"
                >
                  <Mail size={18} className="text-cyan-400" />
                  Email
                </a>
              </div>
            </div>
          </div>

          {/* Related products */}
          <section className="mt-20 border-t border-white/10 pt-12">
            <h2 className="text-2xl font-black mb-8 text-white">Prodotti correlati</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <ProductCard
                  key={i}
                  product={{
                    id: product.id + i,
                    name: `Prodotto Esempio ${i}`,
                    slug: `prodotto-esempio-${i}`,
                    description: "Descrizione prodotto esempio.",
                    shortDescription: "Prodotto di esempio.",
                    price: 19.99 + i * 5,
                    category: product.category,
                    imageUrl: product.imageUrl,
                    customizable: false,
                    stock: 10,
                    featured: false,
                    color: undefined,
                  }}
                />
              ))}
            </div>
          </section>
        </div>
      </section>

      <Footer />
    </main>
  );
}
