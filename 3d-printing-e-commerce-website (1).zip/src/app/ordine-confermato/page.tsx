"use client";

import { useSearchParams } from "next/navigation";
import { useEffect, Suspense } from "react";
import Link from "next/link";
import { CheckCircle2, Mail, Phone, MapPin, Truck } from "lucide-react";
import { ContactBar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function OrderConfirmationPage() {
  return (
    <Suspense fallback={<div>Caricamento...</div>}>
      <OrderConfirmationContent />
    </Suspense>
  );
}

function OrderConfirmationContent() {
  const searchParams = useSearchParams();
  const orderNumber = searchParams.get("orderNumber") || "--";
  const total = searchParams.get("total") || "0";

  useEffect(() => {
    // Track order confirmation
    console.log("Order confirmed:", orderNumber, total);
  }, [orderNumber, total]);

  return (
    <main className="bg-black text-white min-h-screen">
      <ContactBar />

      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center">
            <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce">
              <CheckCircle2 size={32} className="text-green-400" />
            </div>
            <h1 className="text-4xl font-black tracking-tight mb-6 text-white">
              Ordine Confermato!
            </h1>
            <p className="text-white/60 text-lg mb-10">
              Grazie per il tuo ordine. Lo stamperemo con cura e te lo spediremo al più presto.
            </p>

            <div className="bg-white/5 border border-white/10 rounded-3xl p-8 mb-10">
              <div className="flex justify-between items-center mb-4">
                <span className="text-white/60">Numero Ordine</span>
                <span className="text-cyan-400 font-bold font-mono">{orderNumber}</span>
              </div>
              <div className="flex justify-between items-center mb-4">
                <span className="text-white/60">Totale</span>
                <span className="text-cyan-400 font-bold">€{total}</span>
              </div>
              <div className="flex justify-between items-center pt-4 border-t border-white/10">
                <span className="text-white/60 text-sm">Stato</span>
                <span className="text-green-400 text-sm font-medium">In lavorazione</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6 text-center">
                <Mail size={24} className="text-cyan-400 mx-auto mb-3" />
                <h3 className="text-white font-bold mb-2">Email</h3>
                <p className="text-white/60 text-sm">cerraalessandro9@gmail.com</p>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6 text-center">
                <Phone size={24} className="text-orange-400 mx-auto mb-3" />
                <h3 className="text-white font-bold mb-2">Telefono</h3>
                <p className="text-white/60 text-sm">+39 371 422 7933</p>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6 text-center">
                <MapPin size={24} className="text-cyan-400 mx-auto mb-3" />
                <h3 className="text-white font-bold mb-2">Sede</h3>
                <p className="text-white/60 text-sm">Reggiolo (RE)</p>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-3xl p-6 text-center">
              <h3 className="text-white font-bold mb-4">Cosa succede ora?</h3>
              <div className="flex flex-col items-center gap-4 text-white/70 text-sm">
                <div className="flex items-center gap-3">
                  <Truck size={16} className="text-cyan-400" />
                  <span>Prepariamo il tuo ordine per la stampa 3D</span>
                </div>
                <div className="flex items-center gap-3">
                  <Truck size={16} className="text-cyan-400" />
                  <span>Spediamo in tutta Italia con corriere espresso</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail size={16} className="text-cyan-400" />
                  <span>Riceverai aggiornamenti via email e WhatsApp</span>
                </div>
              </div>
            </div>

            <div className="mt-10">
              <Link href="/prodotti" className="text-cyan-400 hover:text-white transition-colors font-medium">
                Torna allo shop →
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
