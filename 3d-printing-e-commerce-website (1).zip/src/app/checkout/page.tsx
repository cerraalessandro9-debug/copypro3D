"use client";

import { useCart } from "@/lib/cart";
import Link from "next/link";
import { ChevronLeft, Mail, Phone, MapPin, CreditCard, Loader2 } from "lucide-react";
import { useState } from "react";
import { ContactBar } from "@/components/Navbar";

export default function CheckoutPage() {
  const { items, total, itemCount, clearCart } = useCart();
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (items.length === 0) {
    return (
      <main className="bg-black text-white min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-black mb-4 text-white">Carrello vuoto</h1>
          <p className="text-white/60 mb-8">Aggiungi prodotti prima di procedere al checkout.</p>
          <Link href="/prodotti" className="bg-gradient-to-r from-cyan-500 via-orange-500 to-cyan-500 text-white font-bold px-8 py-3 rounded-xl hover:shadow-[0_0_30px_rgba(6,182,212,0.4)] transition-all">
            Vai ai Prodotti
          </Link>
        </div>
      </main>
    );
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    const formData = new FormData(e.currentTarget);
    const orderData = {
      customerName: formData.get("customerName"),
      customerEmail: formData.get("customerEmail"),
      customerPhone: formData.get("customerPhone"),
      customerAddress: formData.get("customerAddress"),
      customerCity: formData.get("customerCity"),
      customerCap: formData.get("customerCap"),
      customerProvince: formData.get("customerProvince"),
      items: items.map((item) => ({
        productId: item.productId,
        quantity: item.quantity,
        customStlFileUrl: item.customStlFileUrl || undefined,
        customNotes: item.customNotes || undefined,
      })),
      notes: formData.get("notes") || undefined,
    };

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData),
      });

      if (response.ok) {
        const result = await response.json();
        clearCart();
        // Redirect to success page or show success
        window.location.href = `/ordine-confermato?orderNumber=${result.orderNumber}&total=${result.total}`;
      } else {
        const error = await response.json();
        alert(error.error || "Errore durante l'invio dell'ordine");
      }
    } catch (error) {
      alert("Errore di connessione. Riprova più tardi.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="bg-black text-white min-h-screen">
      <ContactBar />

      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <Link href="/carrello" className="flex items-center gap-2 text-cyan-400 hover:text-white transition-colors">
              <ChevronLeft size={18} /> Torna al carrello
            </Link>
            <h1 className="text-3xl font-black tracking-tight text-white">Checkout</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6 sticky top-24">
                <h3 className="text-white font-bold mb-6">Riepilogo Ordine</h3>
                <div className="space-y-4 mb-6">
                  {items.map((item) => (
                    <div key={item.productId} className="flex justify-between items-start text-sm pb-3 border-b border-white/5 last:border-0">
                      <div>
                        <div className="text-white font-medium">{item.name}</div>
                        <div className="text-white/50 text-xs">x{item.quantity}</div>
                      </div>
                      <span className="text-cyan-400 font-mono">
                        €{(item.price * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="flex justify-between text-sm border-t border-white/10 pt-3 mb-6">
                  <span className="text-white/60">Totale</span>
                  <span className="text-cyan-400 font-bold">€{total.toFixed(2)}</span>
                </div>
                <div className="text-xs text-white/50 mb-6">
                  I prezzi includono l'IVA. La spedizione sarà calcolata in base all'indirizzo.
                </div>
              </div>
            </div>

            {/* Checkout Form */}
            <div className="lg:col-span-2">
              <form onSubmit={handleSubmit} className="space-y-6 bg-white/5 border border-white/10 rounded-3xl p-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Nome e Cognome *</label>
                    <input
                      name="customerName"
                      type="text"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Email *</label>
                    <input
                      name="customerEmail"
                      type="email"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Telefono *</label>
                    <input
                      name="customerPhone"
                      type="tel"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-white mb-2">Indirizzo *</label>
                    <input
                      name="customerAddress"
                      type="text"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-white mb-2">Città *</label>
                    <input
                      name="customerCity"
                      type="text"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">CAP *</label>
                    <input
                      name="customerCap"
                      type="text"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Provincia *</label>
                    <input
                      name="customerProvince"
                      type="text"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-white mb-2">Note sull'ordine</label>
                  <textarea
                    name="notes"
                    rows={3}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                    placeholder="Eventuali richieste o personalizzazioni..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-cyan-500 via-orange-500 to-cyan-500 text-white font-bold py-5 rounded-xl shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:shadow-[0_0_50px_rgba(6,182,212,0.6)] hover:-translate-y-1 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 size={20} className="animate-spin" />
                      Invio ordine...
                    </>
                  ) : (
                    <>
                      <CreditCard size={20} />
                      Conferma Ordine - €{total.toFixed(2)}
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
