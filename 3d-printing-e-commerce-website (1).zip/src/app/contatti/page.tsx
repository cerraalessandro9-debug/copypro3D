"use client";

import Link from "next/link";
import { Mail, Phone, MapPin, Send, Clock, Truck } from "lucide-react";
import { useState } from "react";
import { ContactBar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get("name"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      subject: formData.get("subject"),
      message: formData.get("message"),
    };

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        setSubmitStatus("success");
        (e.currentTarget as HTMLFormElement).reset();
      } else {
        setSubmitStatus("error");
      }
    } catch {
      setSubmitStatus("error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="bg-black text-white min-h-screen">
      <ContactBar />

      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-black tracking-tight text-white mb-4">Contattaci</h1>
            <p className="text-cyan-400 text-lg">
              Hai domande o vuoi ordinare un prodotto personalizzato?<br />
              Siamo qui per aiutarti.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-8">
              <div className="bg-white/5 border border-white/10 rounded-3xl p-8">
                <h2 className="text-2xl font-bold text-white mb-6">I nostri contatti</h2>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-cyan-500/20 rounded-xl flex items-center justify-center text-cyan-400 shrink-0">
                      <Mail size={20} />
                    </div>
                    <div>
                      <h3 className="text-white font-bold">Email</h3>
                      <a href="mailto:cerraalessandro9@gmail.com" className="text-cyan-400 hover:text-white transition-colors">
                        cerraalessandro9@gmail.com
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-orange-500/20 rounded-xl flex items-center justify-center text-orange-400 shrink-0">
                      <Phone size={20} />
                    </div>
                    <div>
                      <h3 className="text-white font-bold">Telefono</h3>
                      <a href="tel:+393714227933" className="text-cyan-400 hover:text-white transition-colors">
                        +39 371 422 7933
                      </a>
                      <p className="text-white/50 text-sm">WhatsApp disponibile</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-cyan-500/20 rounded-xl flex items-center justify-center text-cyan-400 shrink-0">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <h3 className="text-white font-bold">Indirizzo</h3>
                      <p className="text-white/80">
                        Via Giacomo Matteotti 105<br />
                        42046 Reggiolo (RE)<br />
                        Italia
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
                  <div className="flex items-center gap-3">
                    <Clock size={20} className="text-cyan-400" />
                    <div>
                      <h4 className="text-white font-bold">Orari</h4>
                      <p className="text-white/60 text-sm">Lun - Ven: 9:00 - 18:00</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
                  <div className="flex items-center gap-3">
                    <Truck size={20} className="text-orange-400" />
                    <div>
                      <h4 className="text-white font-bold">Spedizioni</h4>
                      <p className="text-white/60 text-sm">In tutta Italia</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white/5 border border-white/10 rounded-3xl p-8">
              <h2 className="text-2xl font-bold text-white mb-6">Scrivici un messaggio</h2>
              {submitStatus === "success" && (
                <div className="bg-green-500/20 border border-green-500/50 text-green-400 rounded-xl p-4 mb-6">
                  Messaggio inviato con successo! Ti risponderemo al più presto.
                </div>
              )}
              {submitStatus === "error" && (
                <div className="bg-red-500/20 border border-red-500/50 text-red-400 rounded-xl p-4 mb-6">
                  Errore nell'invio del messaggio. Riprova più tardi.
                </div>
              )}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-white mb-2">Nome *</label>
                  <input
                    name="name"
                    type="text"
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-white mb-2">Email *</label>
                  <input
                    name="email"
                    type="email"
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-white mb-2">Telefono</label>
                  <input
                    name="phone"
                    type="tel"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-white mb-2">Oggetto</label>
                  <input
                    name="subject"
                    type="text"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-white mb-2">Messaggio *</label>
                  <textarea
                    name="message"
                    rows={5}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-cyan-500 via-orange-500 to-cyan-500 text-white font-bold py-4 rounded-xl shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:shadow-[0_0_50px_rgba(6,182,212,0.6)] hover:-translate-y-1 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <Send size={20} className="animate-spin" />
                  ) : (
                    <>
                      <Send size={20} />
                      Invia Messaggio
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
