import type { Metadata } from "next";
import type { ReactNode } from "react";
import { CartProvider } from "@/lib/cart";
import "./globals.css";

export const metadata: Metadata = {
  title: "CopyPro3D.it - Stampa 3D Professionale",
  description: "Stampa 3D professionale FDM con filamenti PLA. Prodotti personalizzabili tramite file STL. Consegna in tutta Italia.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="it">
      <body className="bg-black text-white antialiased">
        <CartProvider>{children}</CartProvider>
      </body>
    </html>
  );
}
