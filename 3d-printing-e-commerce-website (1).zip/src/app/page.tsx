import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ContactBar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { ProductCard } from "@/components/ProductCard";
import { Footer } from "@/components/Footer";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const featuredProducts = await db.select().from(products).where(eq(products.featured, true));

  const allProducts = await db.select().from(products);

  return (
    <main className="bg-black text-white min-h-screen">
      <ContactBar />

      <Hero />

      {/* Featured Products Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-black tracking-tight mb-2 text-white">
                Prodotti in Evidenza
              </h2>
              <p className="text-cyan-400 text-sm uppercase tracking-wider font-semibold">
                Stampa 3D FDM • Filamenti PLA • Formato STL
              </p>
            </div>
            <a
              href="/prodotti"
              className="text-cyan-400 hover:text-white text-sm font-medium transition-colors"
            >
              Vedi tutti →
            </a>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {(featuredProducts.length > 0 ? featuredProducts : allProducts.slice(0, 4)).map((product) => (
              <ProductCard
                key={product.id}
                product={{
                  id: product.id,
                  name: product.name,
                  slug: product.slug,
                  description: product.description,
                  shortDescription: product.shortDescription ?? undefined,
                  price: Number(product.price ?? 0),
                  category: product.category,
                  imageUrl: product.imageUrl,
                  customizable: product.customizable ?? false,
                  stock: product.stock ?? 0,
                  featured: product.featured ?? false,
                  color: product.color ?? undefined,
                }}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/5 border-y border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-cyan-400/50 transition-colors">
              <div className="w-14 h-14 bg-cyan-500/20 rounded-xl flex items-center justify-center mx-auto mb-6 text-cyan-400">
                <span className="text-2xl">🖨️</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Tecnologia FDM</h3>
              <p className="text-white/60 text-sm leading-relaxed">
                Stampa a deposizione fuso con filamenti PLA di alta qualità per risultati precisi e durevoli.
              </p>
            </div>

            <div className="text-center p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-cyan-400/50 transition-colors">
              <div className="w-14 h-14 bg-orange-500/20 rounded-xl flex items-center justify-center mx-auto mb-6 text-orange-400">
                <span className="text-2xl">📁</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Formato STL</h3>
              <p className="text-white/60 text-sm leading-relaxed">
                Carica i tuoi file STL per prodotti personalizzati o scegli dal nostro catalogo esistente.
              </p>
            </div>

            <div className="text-center p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-cyan-400/50 transition-colors">
              <div className="w-14 h-14 bg-cyan-500/20 rounded-xl flex items-center justify-center mx-auto mb-6 text-cyan-400">
                <span className="text-2xl">🇮🇹</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Made in Italy</h3>
              <p className="text-white/60 text-sm leading-relaxed">
                Progettato e stampato a Reggiolo (RE) con passione e attenzione al dettaglio.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact / CTA */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-cyan-900/90 via-black/90 to-cyan-900/90 border border-white/10 rounded-3xl p-8 md:p-12 text-center shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
            <h2 className="text-3xl font-black text-white mb-6">Hai un'idea?</h2>
            <p className="text-white/60 text-lg mb-8">
              Inviaci il tuo file STL o raccontaci cosa desideri. Realizziamo il tuo oggetto stampato in 3D.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="mailto:cerraalessandro9@gmail.com"
                className="px-8 py-4 bg-white text-black font-bold rounded-xl hover:bg-cyan-400 transition-colors"
              >
                Scrivici via Email
              </a>
              <a
                href="https://wa.me/393714227933"
                className="px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold rounded-xl hover:shadow-[0_0_30px_rgba(34,197,94,0.4)] transition-all"
              >
                WhatsApp +39 371 422 7933
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
