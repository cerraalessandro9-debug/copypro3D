import { products } from "@/db/schema";
import { db } from "@/db";
import { ProductCard } from "@/components/ProductCard";
import { ContactBar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function ProductsPage() {
  const allProducts = await db.select().from(products);

  const categories = [...new Set(allProducts.map((p) => p.category))];

  return (
    <main className="bg-black text-white min-h-screen">
      <ContactBar />

      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-black tracking-tight mb-2 text-white">
            Nostri Prodotti
          </h1>
          <p className="text-cyan-400 text-sm uppercase tracking-wider font-semibold mb-8">
            Stampa 3D FDM • PLA • Personalizzabili con STL
          </p>

          {/* Category filters */}
          <div className="flex flex-wrap gap-3 mb-8">
            <button className="px-4 py-2 bg-cyan-500 text-black rounded-full text-sm font-bold hover:opacity-90 transition-all">
              Tutti
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                className="px-4 py-2 bg-white/5 border border-white/10 text-white/70 rounded-full text-sm hover:border-cyan-400 hover:text-cyan-400 transition-all"
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Products grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {allProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={{
                  id: product.id,
                  name: product.name,
                  slug: product.slug,
                  description: product.description,
                  shortDescription: product.shortDescription ?? undefined,
                  price: Number(product.price ?? 0),
                  category: product.category,
                  imageUrl: product.imageUrl,
                  customizable: product.customizable ?? false,
                  stock: product.stock ?? 0,
                  featured: product.featured ?? false,
                  color: product.color ?? undefined,
                }}
              />
            ))}
            {allProducts.length === 0 && (
              <div className="col-span-full text-center py-20 text-white/60">
                Nessun prodotto disponibile al momento.
              </div>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
