import { pgTable, serial, text, integer, timestamp, boolean, numeric, varchar } from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  shortDescription: text("short_description"),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  category: text("category").notNull(), // e.g., "gadgets", "home", "toys", "custom"
  imageUrl: text("image_url").notNull(),
  galleryImages: text("gallery_images").array().default([]),
  stlFileUrl: text("stl_file_url"), // URL to downloadable STL for customizable products
  customizable: boolean("customizable").default(false),
  stock: integer("stock").default(0),
  featured: boolean("featured").default(false),
  weight: text("weight"), // e.g., "50g"
  dimensions: text("dimensions"), // e.g., "10x5x3 cm"
  color: text("color"), // default PLA color
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone").notNull(),
  customerAddress: text("customer_address").notNull(),
  customerCity: text("customer_city").notNull(),
  customerCap: text("customer_cap").notNull(),
  customerProvince: text("customer_province").notNull(),
  total: numeric("total", { precision: 10, scale: 2 }).notNull(),
  status: text("status").default("pending").notNull(), // pending, confirmed, shipped, delivered, cancelled
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().references(() => orders.id),
  productId: integer("product_id").notNull().references(() => products.id),
  quantity: integer("quantity").notNull().default(1),
  priceAtPurchase: numeric("price_at_purchase", { precision: 10, scale: 2 }).notNull(),
  customStlFileUrl: text("custom_stl_file_url"), // if customer uploaded their own STL
  customNotes: text("custom_notes"), // customization notes from customer
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type NewProduct = typeof products.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type NewOrder = typeof orders.$inferInsert;
export type OrderItem = typeof orderItems.$inferSelect;
export type NewOrderItem = typeof orderItems.$inferInsert;
